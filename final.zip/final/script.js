function onav() {
document.getElementById("myside").style.width="250px";
//document.getElementById("main").style.marginRight="250px";
}

function clsnav() {
document.getElementById("myside").style.width="0";
//document.getElementById("main").style.marginRight="0";
}






function func1() {
    

document.getElementById("heading").innerHTML="Wall Decoration Items";
document.getElementById("para").innerHTML="A few years back,the wall decorations and wall arts was largely ignored and scarcely used.It used as the last option after all home accessories were taken care of.But today,wall decorations and wall arts has become a stunning design opportunity.They beautifies entire room.A suitable wall art can help you to display your personality and lifestyle.our creators can create stunning art pieces that going to match your personality,lifestyle and your expectations.some of our favorite wall decorations are included in the gallery below."; 
document.getElementById("a1").href="images/wall1.jpg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/wall2.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/wall3.jpg";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/wall4.jpg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/wall5.jpg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/wall6.jpg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/wall7.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/wall8.jpg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/wall9.jpeg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/wall1.jpg";
document.getElementById("i2").src="images/wall2.jpeg";
document.getElementById("i3").src="images/wall3.jpg";
document.getElementById("i4").src="images/wall4.jpg";
document.getElementById("i5").src="images/wall5.jpg";
document.getElementById("i6").src="images/wall6.jpg";
document.getElementById("i7").src="images/wall7.jpeg";
document.getElementById("i8").src="images/wall8.jpg";
document.getElementById("i9").style.display="block";
document.getElementById("i9").src="images/wall9.jpeg";
}

function func2() {
document.getElementById("heading").innerHTML="Indoor Plants&Pots";
document.getElementById("para").innerHTML="Keeping plants indoors can help purify the air, brighten up your room, and if you are growing edible herbs,can be useful in the kitchen as well.Our indoor plant pots up these advantages by adding style to your interior spaces. There’s the unique and modern HANTVERK or the rustic and charming bamboo KAFFEBon all ready to blend in with your choice of decor. We even have hanging pots like the elegant SKURAR or the self-watering SOMMARFEST you can simply fix them to a wall if there’s floor space lacking!"; 
document.getElementById("a1").href="images/p1.jpg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/p2.jpg";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/p3.jpg";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/p4.jpg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/p5.jpg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/p6.jpg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/p7.jpg";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/p8.jpg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/p8.jpg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/p1.jpg";
document.getElementById("i2").src="images/p2.jpg";
document.getElementById("i3").src="images/p3.jpg";
document.getElementById("i4").src="images/p4.jpg";
document.getElementById("i5").src="images/p5.jpg";
document.getElementById("i6").src="images/p6.jpg";
document.getElementById("i7").src="images/p7.jpg";
document.getElementById("i8").src="images/p8.jpg";
document.getElementById("i9").style.display="block";
document.getElementById("i9").src="images/p8.jpg";
}

function func3() {
document.getElementById("heading").innerHTML="Designer Lights";
document.getElementById("para").innerHTML="Wall lights are a subtle way to lift your room’s style – and a strong way to improve your every day. Whether you want bedroom wall lights for night-time reading or living room LED wall lights for daytime working, we have lots of designs. Just find the chameleon that blends in with your look"; 

document.getElementById("a1").href="images/l1.jpg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/l2.jpg";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/l3.jpg";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/l4.jpg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/l5.jpg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/l6.jpg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/l7.jpg";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/l8.jpg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/l9.jpg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/l1.jpg";
document.getElementById("i2").src="images/l2.jpg";
document.getElementById("i3").src="images/l3.jpg";
document.getElementById("i4").src="images/l4.jpg";
document.getElementById("i5").src="images/l5.jpg";
document.getElementById("i6").src="images/l6.jpg";
document.getElementById("i7").src="images/l7.jpg";
document.getElementById("i8").src="images/l8.jpg";
document.getElementById("i9").style.display="block";
document.getElementById("i9").src="images/l9.jpg";
}


function func4() {
document.getElementById("heading").innerHTML="Acquariums";
document.getElementById("para").innerHTML="Aquariums are always a nice part of home décor, as they can add a pop of color to an otherwise neutral space, and they can be very entertaining to look at. However, besides being aesthetically pleasing, they are also beneficial to your health. Studies have shown that aquariums can help reduce anxiety, stress, and pain. They can also help you sleep better, and they can boost your creativity when needed.  These are just some of the reasons why aquariums are so popular today, especially in bigger residential units.";
document.getElementById("a1").href="images/a1.jpg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/a2.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/a3.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/a4.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/a5.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/a6.jpg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/a7.jpg";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/a8.jpg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/a9.jpg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/a1.jpg";
document.getElementById("i2").src="images/a2.jpeg";
document.getElementById("i3").src="images/a3.jpeg";
document.getElementById("i4").src="images/a4.jpeg";
document.getElementById("i5").src="images/a5.jpeg";
document.getElementById("i6").src="images/a6.jpg";
document.getElementById("i7").src="images/a7.jpg";
document.getElementById("i8").src="images/a8.jpg";
document.getElementById("i9").style.display="none";
}

function func5() {
document.getElementById("heading").innerHTML="Artificial Fireplace";
document.getElementById("para").innerHTML="When it comes to adding warmth and charm to a home, nothing quite compares to a roaring fireplace. The crackling sound of the wood, the ambient flow from the fire, and the nice warmth that it can provide.If you aren’t fortunate enough to have a fireplace in your home, you may be interested in purchasing an electric fireplace to get those similar effects without the hassle of installing a conventional fireplace.The electric fireplace isn’t a new innovation by a long shot. In fact, the electric fire has been around for over 100 years, as it was invented in 1912 and its popularity really took off in the 1950s";
document.getElementById("a1").href="images/f1.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/f2.png";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/f3.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/f4.jpg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/f5.jpg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/f6.jpg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/f7.jpg";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/f8.jpg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/f8.jpg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/f1.jpeg";
document.getElementById("i2").src="images/f2.png";
document.getElementById("i3").src="images/f3.jpeg";
document.getElementById("i4").src="images/f4.jpg";
document.getElementById("i5").src="images/f5.jpg";
document.getElementById("i6").src="images/f6.jpg";
document.getElementById("i7").src="images/f7.jpg";
document.getElementById("i8").src="images/f8.jpg";
document.getElementById("i9").style.display="none";
}


function func6() {
document.getElementById("heading").innerHTML="Flooring";
document.getElementById("para").innerHTML="Flooring is a crucial part of any interior design and can easily make or break your space. While our first interaction with a space is visual, the first physical contact a person will have with your space is the flooring. It serves as a foundation to your design and can ultimately impact its overall success.Regardless of which design style you have chosen, selecting a complimentary flooring option is a must. "; 

document.getElementById("a1").href="images/floor1.jpg";
console.log("Hyperlink Changed");
document.getElementById("a2").href="images/floor2.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a3").href="images/floor3.png";
console.log("Hyperlink Changed");
document.getElementById("a4").href="images/floor4.jpg";
console.log("Hyperlink Changed");
document.getElementById("a5").href="images/floor5.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a6").href="images/floor6.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a7").href="images/floor7.png";
console.log("Hyperlink Changed");
document.getElementById("a8").href="images/floor8.jpeg";
console.log("Hyperlink Changed");
document.getElementById("a9").href="images/floor9.jpeg";
console.log("Hyperlink Changed");
document.getElementById("i1").src="images/floor1.jpg";
document.getElementById("i2").src="images/floor2.jpeg";
document.getElementById("i3").src="images/floor3.png";
document.getElementById("i4").src="images/floor4.jpg";
document.getElementById("i5").src="images/floor5.jpeg";
document.getElementById("i6").src="images/floor6.jpeg";
document.getElementById("i7").src="images/floor7.png";
document.getElementById("i8").src="images/floor8.jpeg";
document.getElementById("i9").style.display="block";
document.getElementById("i9").src="images/floor9.jpeg";
}
